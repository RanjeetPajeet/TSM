## v4.12.32 Changes

* [All] Fixed various UI errors
* [Retail] Fixed error when opening profession

[Known Issues](https://support.tradeskillmaster.com/en_US/known_issues)
